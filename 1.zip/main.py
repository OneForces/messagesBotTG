# main.py

from gui.main_window import launch_gui

if __name__ == "__main__":
    launch_gui()
